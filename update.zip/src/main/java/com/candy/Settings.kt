package com.candy

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.rounded.AccountBalance
import androidx.compose.material.icons.rounded.Block
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.BubbleChart
import androidx.compose.material.icons.rounded.ContactPhone
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Diamond
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Menu
import androidx.compose.material.icons.rounded.Palette
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.vector.ImageVector
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.res.Configuration
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.Locale

/** What you chose in Accessibility (the look and the language). Kept on this phone. */
object AppPrefs {
    private const val FILE = "candy_app_prefs"

    /** "system", "light" or "dark". */
    var theme by mutableStateOf("system")
        private set

    /** "system", "ar" or "en". */
    var language by mutableStateOf("system")
        private set

    private fun sp(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun init(c: Context) {
        theme = sp(c).getString("theme", "system") ?: "system"
        language = sp(c).getString("language", "system") ?: "system"
    }

    fun setTheme(c: Context, v: String) {
        theme = v
        sp(c).edit().putString("theme", v).apply()
    }

    fun setLanguage(c: Context, v: String) {
        language = v
        sp(c).edit().putString("language", v).apply()
    }

    /** Gives the activity the saved language before anything is drawn. */
    fun wrap(base: Context): Context {
        val lang = base.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("language", "system") ?: "system"
        if (lang != "ar" && lang != "en") return base
        val locale = Locale(lang)
        Locale.setDefault(locale)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(locale)
        cfg.setLayoutDirection(locale)
        return base.createConfigurationContext(cfg)
    }
}

private fun Context.activityOrNull(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

// ───────────────────────── building blocks ─────────────────────────

/** A small arrow that points to the end of the row, and flips in right-to-left languages. */
@Composable
private fun Chevron() {
    val color = MaterialTheme.colorScheme.onSurfaceVariant
    val rtl = LocalLayoutDirection.current == LayoutDirection.Rtl
    Canvas(Modifier.size(18.dp)) {
        val w = size.width
        val h = size.height
        val a = if (rtl) w * 0.68f else w * 0.32f
        val b = if (rtl) w * 0.32f else w * 0.68f
        val p = Path().apply {
            moveTo(a, h * 0.2f)
            lineTo(b, h * 0.5f)
            lineTo(a, h * 0.8f)
        }
        drawPath(p, color, style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

/** The icon that goes with each old emoji, so every row of every settings page looks the same. */
private fun symbolFor(emoji: String): ImageVector? = when (emoji) {
    "🔖" -> Icons.Rounded.Bookmark
    "🗂️" -> Icons.Rounded.Folder
    "💬" -> Icons.Outlined.ChatBubbleOutline
    "🔒" -> Icons.Rounded.Lock
    "🫧" -> Icons.Rounded.BubbleChart
    "🚫" -> Icons.Rounded.Block
    "🎨" -> Icons.Rounded.Palette
    "🚪" -> Icons.AutoMirrored.Rounded.Logout
    "🔐" -> Icons.Rounded.Shield
    "💎" -> Icons.Rounded.Diamond
    "⚙️" -> Icons.Rounded.Settings
    "👀" -> Icons.Rounded.Visibility
    "📈" -> Icons.Rounded.Insights
    "📇" -> Icons.Rounded.ContactPhone
    "🔑" -> Icons.Rounded.Key
    "🗝️" -> Icons.Rounded.VpnKey
    "🏛️" -> Icons.Rounded.AccountBalance
    "🔗" -> Icons.Rounded.Link
    "🗑️" -> Icons.Rounded.Delete
    else -> null
}

/** One row of a settings list: an icon in a soft square, a title, an optional line under it, and an arrow. */
@Composable
internal fun SettingsRow(
    title: String,
    subtitle: String? = null,
    emoji: String? = null,
    icon: (@Composable () -> Unit)? = null,
    arrow: Boolean = true,
    danger: Boolean = false,
    onClick: () -> Unit,
) {
    val scheme = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = Space.lg, vertical = Space.md),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(Space.lg),
    ) {
        val symbol = if (emoji != null) symbolFor(emoji) else null
        Box(
            Modifier
                .size(40.dp)
                .clip(MaterialTheme.shapes.small)
                .background(if (danger) scheme.errorContainer.copy(alpha = 0.5f) else if (icon != null) Color.Transparent else scheme.surfaceContainerHigh),
            contentAlignment = Alignment.Center,
        ) {
            when {
                icon != null -> icon()
                symbol != null -> Icon(
                    symbol,
                    contentDescription = null,
                    tint = if (danger) scheme.error else scheme.primary,
                    modifier = Modifier.size(22.dp),
                )
                emoji != null -> Text(emoji, fontSize = 22.sp)
            }
        }
        Column(Modifier.weight(1f)) {
            Text(
                title,
                style = MaterialTheme.typography.bodyLarge,
                color = if (danger) scheme.error else scheme.onSurface,
            )
            if (subtitle != null) Muted(subtitle)
        }
        if (arrow) Chevron()
    }
}

@Composable
internal fun GroupLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = Space.lg, end = Space.lg, top = Space.xl, bottom = Space.xs),
    )
}

/** A thin line between groups. */
@Composable
internal fun GroupDivider() {
    Box(Modifier.fillMaxWidth().padding(top = Space.sm).height(1.dp).background(CandyBrand.hairline()))
}

@Composable
internal fun KanadeLogo(size: androidx.compose.ui.unit.Dp = 28.dp) {
    Image(painterResource(R.drawable.kanade_account_logo), contentDescription = null, modifier = Modifier.size(size))
}

// ───────────────────────── Settings and activity ─────────────────────────

/** The page the three lines on your profile open. */
@Composable
fun SettingsScreen(
    net: Net,
    onBack: () -> Unit,
    onKanadeAccount: () -> Unit,
    onSaved: () -> Unit,
    onMemories: () -> Unit,
    onPrivacy: () -> Unit,
    onBubbles: () -> Unit,
    onBlocks: () -> Unit,
    onBadge: () -> Unit,
    onAccessibility: () -> Unit,
    onSignOut: () -> Unit,
) {
    var messages by remember { mutableStateOf(false) }
    var confirmOut by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.set_title), onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            GroupLabel(stringResource(R.string.set_your_account))
            SettingsRow(
                title = stringResource(R.string.set_kanade_account),
                subtitle = stringResource(R.string.set_kanade_account_sub),
                icon = { KanadeLogo() },
                onClick = onKanadeAccount,
            )
            Muted(stringResource(R.string.set_kanade_account_note), Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
            GroupDivider()

            GroupLabel(stringResource(R.string.set_how_use))
            SettingsRow(stringResource(R.string.set_saved), emoji = "🔖", onClick = onSaved)
            SettingsRow(stringResource(R.string.mem_title), emoji = "🗂️", onClick = onMemories)
            SettingsRow(stringResource(R.string.set_messages), emoji = "💬", onClick = { messages = true })
            SettingsRow(stringResource(R.string.set_privacy), emoji = "🔒", onClick = onPrivacy)
            SettingsRow(
                stringResource(R.string.badge_title),
                subtitle = stringResource(R.string.badge_row_sub),
                icon = { BadgeIcon("crown", 28.dp) },
                onClick = onBadge,
            )
            SettingsRow(stringResource(R.string.prof_bubbles), emoji = "🫧", onClick = onBubbles)
            SettingsRow(stringResource(R.string.set_blocks), emoji = "🚫", onClick = onBlocks)
            GroupDivider()

            GroupLabel(stringResource(R.string.set_more))
            SettingsRow(stringResource(R.string.set_accessibility), emoji = "🎨", onClick = onAccessibility)
            SettingsRow(stringResource(R.string.prof_signout), emoji = "🚪", arrow = false, danger = true, onClick = { confirmOut = true })
            Box(Modifier.height(LocalBarInset.current + 16.dp))
        }
    }

    if (messages) MessageSettingsDialog(net) { messages = false }
    if (confirmOut) {
        AlertDialog(
            onDismissRequest = { confirmOut = false },
            title = { Text(stringResource(R.string.prof_signout)) },
            text = { Text(stringResource(R.string.set_signout_confirm)) },
            confirmButton = {
                TextButton(onClick = { confirmOut = false; onSignOut() }) { Text(stringResource(R.string.prof_signout)) }
            },
            dismissButton = { TextButton(onClick = { confirmOut = false }) { Text(stringResource(R.string.cancel)) } },
        )
    }
}

// ───────────────────────── Kanade Account ─────────────────────────

@Composable
fun KanadeAccountScreen(onBack: () -> Unit, onSecurity: () -> Unit, onSubscriptions: () -> Unit, onManage: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.set_kanade_account), onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Box(Modifier.fillMaxWidth().padding(vertical = 16.dp), contentAlignment = Alignment.Center) { KanadeLogo(72.dp) }
            SettingsRow(stringResource(R.string.sec_title), emoji = "🔐", onClick = onSecurity)
            SettingsRow(stringResource(R.string.set_subscriptions), emoji = "💎", onClick = onSubscriptions)
            SettingsRow(stringResource(R.string.set_manage_account), emoji = "⚙️", onClick = onManage)
            Box(Modifier.height(LocalBarInset.current + 16.dp))
        }
    }
}

// ───────────────────────── Manage Account ─────────────────────────

/** What used to sit at the bottom of the profile: visitors, growth, join date and location. */
@Composable
fun ManageAccountScreen(net: Net, onBack: () -> Unit, onVisits: () -> Unit, onGrowth: () -> Unit, onSignOut: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var me by remember { mutableStateOf<JSONObject?>(null) }
    var reload by remember { mutableStateOf(0) }
    var error by remember { mutableStateOf("") }

    LaunchedEffect(reload) {
        val r = net.get("/candy/me")
        if (r.ok) me = r.body else error = r.message(ctx)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.set_manage_account), onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Box(Modifier.padding(horizontal = 16.dp)) { ErrorText(error) }
            SettingsRow(stringResource(R.string.prof_visits), emoji = "👀", onClick = onVisits)
            SettingsRow(stringResource(R.string.prof_growth), emoji = "📈", onClick = onGrowth)
            GroupDivider()
            val data = me
            if (data != null) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(stringResource(R.string.prof_show_join), Modifier.weight(1f))
                    Switch(
                        checked = data.optBoolean("showJoinDate", true),
                        onCheckedChange = { on ->
                            scope.launch {
                                val r = net.post("/candy/joindate", JSONObject().put("visible", on))
                                if (r.ok) reload++ else error = r.message(ctx)
                            }
                        },
                    )
                }
                val loc = data.optJSONObject("location")
                if (loc != null) {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Text(stringResource(R.string.prof_show_location, loc.optString("text")), Modifier.weight(1f))
                        Switch(
                            checked = loc.optBoolean("visible", true),
                            onCheckedChange = { on ->
                                scope.launch {
                                    val r = net.post("/candy/location/visibility", JSONObject().put("visible", on))
                                    if (r.ok) reload++ else error = r.message(ctx)
                                }
                            },
                        )
                    }
                } else {
                    Muted(stringResource(R.string.prof_location_hint), Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                }
            }
            GroupDivider()
            AccountDangerSection(net, onSignOut)
            Box(Modifier.height(LocalBarInset.current + 16.dp))
        }
    }
}

// ───────────────────────── Accessibility ─────────────────────────

@Composable
private fun ChoiceRow(label: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Text(label, style = MaterialTheme.typography.bodyLarge)
    }
}

/** Light or dark, and Arabic or English. */
@Composable
fun AccessibilityScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.set_accessibility), onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            GroupLabel(stringResource(R.string.set_theme))
            ChoiceRow(stringResource(R.string.set_theme_system), AppPrefs.theme == "system") { AppPrefs.setTheme(ctx, "system") }
            ChoiceRow(stringResource(R.string.set_theme_light), AppPrefs.theme == "light") { AppPrefs.setTheme(ctx, "light") }
            ChoiceRow(stringResource(R.string.set_theme_dark), AppPrefs.theme == "dark") { AppPrefs.setTheme(ctx, "dark") }
            GroupDivider()
            GroupLabel(stringResource(R.string.set_language))
            fun pick(v: String) {
                if (AppPrefs.language == v) return
                AppPrefs.setLanguage(ctx, v)
                // the screen is rebuilt in the new language
                ctx.activityOrNull()?.recreate()
            }
            ChoiceRow(stringResource(R.string.set_lang_system), AppPrefs.language == "system") { pick("system") }
            ChoiceRow(stringResource(R.string.set_lang_ar), AppPrefs.language == "ar") { pick("ar") }
            ChoiceRow(stringResource(R.string.set_lang_en), AppPrefs.language == "en") { pick("en") }
            Box(Modifier.height(LocalBarInset.current + 16.dp))
        }
    }
}

// ───────────────────────── Saved ─────────────────────────

/** The tracks and loops you saved with the bookmark. */
@Composable
fun SavedScreen(net: Net, onBack: () -> Unit, onOpenPost: (String) -> Unit, onOpenLoop: (String) -> Unit) {
    val ctx = LocalContext.current
    var tab by remember { mutableStateOf(0) }
    var tracks by remember { mutableStateOf<List<Post>>(emptyList()) }
    var loops by remember { mutableStateOf<List<Post>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        loading = true
        val a = net.get("/candy/saved?kind=track")
        val b = net.get("/candy/saved?kind=loop")
        loading = false
        if (a.ok) tracks = a.body?.optJSONArray("items").toPosts() else error = a.message(ctx)
        if (b.ok) loops = b.body?.optJSONArray("items").toPosts() else error = b.message(ctx)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.set_saved), onBack)
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            androidx.compose.material3.FilterChip(
                selected = tab == 0,
                onClick = { tab = 0 },
                label = { Text(stringResource(R.string.saved_tracks)) },
            )
            androidx.compose.material3.FilterChip(
                selected = tab == 1,
                onClick = { tab = 1 },
                label = { Text(stringResource(R.string.saved_loops)) },
            )
        }
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ErrorText(error)
            if (loading) Loading()
            val shown = if (tab == 0) tracks else loops
            if (!loading && shown.isEmpty() && error.isEmpty()) Muted(stringResource(R.string.saved_empty))
            if (shown.isNotEmpty()) {
                SavedGrid(net, shown, loops = tab == 1) { id -> if (tab == 1) onOpenLoop(id) else onOpenPost(id) }
            }
            Box(Modifier.height(LocalBarInset.current + 16.dp))
        }
    }
}

// ───────────────────────── Account Privacy ─────────────────────────

/** Public or private, and the requests to follow you while you are private. */
@Composable
fun AccountPrivacyScreen(net: Net, onBack: () -> Unit, onOpenProfile: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var isPrivate by remember { mutableStateOf<Boolean?>(null) }
    var requests by remember { mutableStateOf<List<CUser>>(emptyList()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var reload by remember { mutableStateOf(0) }

    LaunchedEffect(reload) {
        val me = net.get("/candy/me")
        if (me.ok) isPrivate = me.body?.optBoolean("accountPrivate") == true else error = me.message(ctx)
        val r = net.get("/candy/requests")
        if (r.ok) requests = r.body?.optJSONArray("users").toUsers()
    }

    suspend fun setPrivate(on: Boolean) {
        busy = true
        error = ""
        val r = net.post("/candy/privacy", JSONObject().put("private", on))
        busy = false
        if (r.ok) reload++ else error = r.message(ctx)
    }

    suspend fun answer(u: CUser, accept: Boolean) {
        busy = true
        error = ""
        val r = net.post(if (accept) "/candy/request/accept" else "/candy/request/decline", JSONObject().put("hash", bareHash(u.hash)))
        busy = false
        if (r.ok) reload++ else error = r.message(ctx)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.set_privacy), onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Box(Modifier.padding(horizontal = 16.dp)) { ErrorText(error) }
            val current = isPrivate
            if (current != null) {
                PrivacyChoice(
                    title = stringResource(R.string.privacy_public),
                    desc = stringResource(R.string.privacy_public_desc),
                    selected = !current,
                ) { if (current && !busy) scope.launch { setPrivate(false) } }
                PrivacyChoice(
                    title = stringResource(R.string.privacy_private),
                    desc = stringResource(R.string.privacy_private_desc),
                    selected = current,
                ) { if (!current && !busy) scope.launch { setPrivate(true) } }
            }
            GroupDivider()
            GroupLabel(stringResource(R.string.privacy_requests))
            if (requests.isEmpty()) Muted(stringResource(R.string.privacy_no_requests), Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
            for (u in requests) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(
                        Modifier.weight(1f).clickable { onOpenProfile(u.hash) },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Avatar(u.hash, net.token, 44.dp)
                        Column {
                            Text(u.name.ifBlank { u.hash }, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1)
                            Muted(u.hash)
                        }
                    }
                    androidx.compose.material3.Button(onClick = { scope.launch { answer(u, true) } }, enabled = !busy) {
                        Text(stringResource(R.string.privacy_accept))
                    }
                    androidx.compose.material3.OutlinedButton(onClick = { scope.launch { answer(u, false) } }, enabled = !busy) {
                        Text(stringResource(R.string.privacy_decline))
                    }
                }
            }
            Box(Modifier.height(LocalBarInset.current + 16.dp))
        }
    }
}

@Composable
private fun PrivacyChoice(title: String, desc: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RadioButton(selected = selected, onClick = onClick)
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Muted(desc)
        }
    }
}

// ───────────────────────── Blocks ─────────────────────────

/** The accounts you blocked, with a button to unblock each. */
@Composable
fun BlocksScreen(net: Net, onBack: () -> Unit, onOpenProfile: (String) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var users by remember { mutableStateOf<List<CUser>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var reload by remember { mutableStateOf(0) }

    LaunchedEffect(reload) {
        val r = net.get("/candy/blocks")
        loading = false
        if (r.ok) users = r.body?.optJSONArray("users").toUsers() else error = r.message(ctx)
    }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader(stringResource(R.string.set_blocks), onBack)
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Box(Modifier.padding(horizontal = 16.dp)) { ErrorText(error) }
            if (loading) Loading()
            if (!loading && users.isEmpty() && error.isEmpty()) {
                Muted(stringResource(R.string.blocks_empty), Modifier.padding(horizontal = 16.dp, vertical = 12.dp))
            }
            for (u in users) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                    Row(
                        Modifier.weight(1f).clickable { onOpenProfile(u.hash) },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                    ) {
                        Avatar(u.hash, net.token, 44.dp)
                        Column {
                            Text(u.name.ifBlank { u.hash }, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, maxLines = 1)
                            Muted(u.hash)
                        }
                    }
                    androidx.compose.material3.OutlinedButton(
                        onClick = {
                            scope.launch {
                                busy = true
                                error = ""
                                val r = net.post("/candy/unblock", JSONObject().put("hash", bareHash(u.hash)))
                                busy = false
                                if (r.ok) reload++ else error = r.message(ctx)
                            }
                        },
                        enabled = !busy,
                    ) { Text(stringResource(R.string.prof_unblock)) }
                }
            }
            Box(Modifier.height(LocalBarInset.current + 16.dp))
        }
    }
}

/** The three lines on your profile. They open Settings and activity. */
@Composable
fun SettingsMenuButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val desc = stringResource(R.string.set_open)
    androidx.compose.material3.Surface(
        onClick = onClick,
        shape = androidx.compose.foundation.shape.CircleShape,
        color = Color.Black.copy(alpha = 0.35f),
        modifier = modifier.size(42.dp).androidSemantics(desc),
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Menu, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
        }
    }
}

private fun Modifier.androidSemantics(desc: String): Modifier =
    this.then(Modifier.semantics { contentDescription = desc })
